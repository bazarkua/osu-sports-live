import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>
          React app is running
        </p>
      </header>
    </div>
  );
}

export default App;
